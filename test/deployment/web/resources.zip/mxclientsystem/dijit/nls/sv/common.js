//>>built
define("dijit/nls/sv/common",({buttonOk:"OK",buttonCancel:"Avbryt",buttonSave:"Spara",itemClose:"Stäng"}));
