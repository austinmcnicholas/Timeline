//>>built
define("dijit/form/nls/bs/validate",{invalidMessage:"Unešena vrijednost je neispravna",missingMessage:"Ova vrijednost je obavezna",rangeMessage:"Ova vrijednost je izvan raspona."});
